# Animales > 2024-12-13 8:39pm
https://universe.roboflow.com/dmmontero/animales-7lgay

Provided by a Roboflow user
License: CC BY 4.0

